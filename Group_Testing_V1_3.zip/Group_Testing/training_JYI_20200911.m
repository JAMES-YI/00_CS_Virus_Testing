% This file is for training purpose.
% 
% Created by JYI, 09/11/2020
% 
%%
% handles = 
% 
%                        figure1: [1x1 Figure]
%                      sys_panel: [1x1 Panel]
%                      srd_panel: [1x1 Panel]
%                      epr_panel: [1x1 Panel]
%                   mixmat_panel: [1x1 Panel]
%                 srd_controller: [1x1 Panel]
%                        srd_tab: [1x1 Table]
%                 epr_controller: [1x1 Panel]
%                        epr_tab: [1x1 Table]
%                 mmd_controller: [1x1 Panel]
%                     mixmat_tab: [1x1 Table]
%               sampressave_push: [1x1 UIControl]
%         sampresreviewnext_push: [1x1 UIControl]
%     sampresreviewprevious_push: [1x1 UIControl]
%           sampresreview_static: [1x1 UIControl]
%               poolresnext_push: [1x1 UIControl]
%         poolresreviewnext_push: [1x1 UIControl]
%     poolresreviewprevious_push: [1x1 UIControl]
%           poolresreview_static: [1x1 UIControl]
%             poolresfinish_push: [1x1 UIControl]
%           poolresstartnew_push: [1x1 UIControl]
%              poolresent_static: [1x1 UIControl]
%                  mmd_next_push: [1x1 UIControl]
%                 mixmatgen_push: [1x1 UIControl]
%               mixmatsize_popup: [1x1 UIControl]
%              mixmatsize_static: [1x1 UIControl]
%                         output: [1x1 Figure]


%%
handles.mixmatsize_popup.UserData